#!/bin/sh
LOCALDIR="$(cd $(dirname $0); pwd)"
bin=$LOCALDIR/bin
home=$LOCALDIR/rom
brotli=$bin/Linux/brotli
sdat2img=$bin/sdat2img.py
gettype1=$bin/Linux/gettype
simg2img=$bin/Linux/simg2img
lpunpack=$bin/Linux/lpunpack
payload_un=$bin/Linux/payload-dumper-go
erofsUnpackKt=$bin/Linux/erofsUnpackKt
mkfs=$bin/Linux/mkfs.erofs
mke2fs=$bin/Linux/mke2fs
e2fsdroid=$bin/Linux/e2fsdroid
img2simg=$bin/Linux/img2simg
SYSTEM_DIR=$home/out/system
ApkTool="java -jar $bin/apktool.jar"
SYSTEM_AVB=$home/out
AIK="$bin/AIK"
img2simg=$bin/Linux/img2simg

cecho(){ echo -e "\033[31m[$(date '+%H:%M:%S')]${1}\033[0m" ; } #颜色红

function Home()
{
    if [ -f $LOCALDIR/makesuper.sh ]; then
        rm -rf $LOCALDIR/makesuper.sh
    fi
    if [ -f $LOCALDIR/rimg2simg.sh ]; then
        rm -rf $LOCALDIR/rimg2simg.sh
    fi
    clear
    echo -e "\033[2;33m|---------------------------------------------------------|\033[0m"
    echo -e "\033[1;31m|-              [欢迎使用MIUI通用处理工具]               -|\033[0m"
    echo -e "\033[2;33m|-----------------------[解压目录]------------------------|\033[0m"
    echo -e "\033[2;32m|      [1.解压zip     ]            [2.解压Br      ]       |\033[0m"
    echo -e "\033[2;32m|      [3.解压Dat     ]            [4.解压img     ]       |\033[0m"
    echo -e "\033[2;32m|      [5.解压Super   ]            [6.解压Payload ]       |\033[0m"
    echo -e "\033[2;33m|-----------------------[打包目录]------------------------|\033[0m"
    echo -e "\033[2;32m|      [7.打包zip     ]            [8.打包Br      ]       |\033[0m"
    echo -e "\033[2;32m|      [9.打包Dat     ]            [10.打包img    ]       |\033[0m"
    echo -e "\033[2;32m|      [11.打包Super  ]            [12.打包Payload]       |\033[0m"
    echo -e "\033[2;33m|---------------------------------------------------------|\033[0m"
    echo -e "\033[1;33m|                  [    000.一键制作    ]                 |\033[0m"
    echo -e "\033[2;33m|---------------------------------------------------------|\033[0m"
    echo -e "\033[1;32m|                  [111.MIUI通用修改菜单]                 |\033[0m"
    echo -e "\033[1;32m|                  [    222.处理权限    ]                 |\033[0m"
    echo -e "\033[1;32m|                  [  333.删除全部文件  ]                 |\033[0m"
    echo -e "\033[2;33m|---------------------------------------------------------|\033[0m"
    echo -e "\033[1;31m|                         [0.退出]                        |\033[0m"
    echo -e "\033[2;33m|---------------------------------------------------------|\033[0m"
    echo -e "\033[1;35m                      [请输入您的选择]\033[0m"
    read -p "--[请输入数字]: " xuanze
    case $xuanze in
        1)
            unzipd
        ;;
		2)
		    unbr
        ;;
		3)
		    undat
        ;;
		4)
            unimg
		;;
		5)
            unsuper
		;;		
		6)
            jieyabin
		;;		
		7)
            makezip
        ;;
        8)
            makebr
        ;;
        9)
            makedat
        ;;
        10)
            makeimgg
        ;;
        11)
            makesuper
        ;;
        12)
            cecho "\033[1;31m 暂未开放\033[0m"
            sleep 2
            Home
        ;;
        111)
            cp $bin/MIUI.sh $LOCALDIR/MIUI.sh
            sudo bash ./MIUI.sh
            rm -rf ./MIUI.sh
            Home
        ;;
        222)
            cecho "\033[1;32m 正在处理权限...\033[0m"
            sleep 1
            sudo chmod -R 777 $home
            cecho "\033[1;32m 处理完成\033[0m"
            sleep 1
            Home
        ;;
        333)
            cecho "\033[1;32m 清除中...\033[0m"
            cp $bin/rm.sh $LOCALDIR/rm.sh
            bash ./rm.sh
            cecho "\033[1;32m 清除完成\033[0m"
            rm -rf ./rm.sh
            sleep 2
            Home
        ;;
        000)
            cp $bin/onekey.sh $LOCALDIR/onekey.sh
            sudo bash ./onekey.sh
            rm -rf ./onekey.sh
            Home
        ;;
        0)
            clear
            exit
		;;
        *)
            echo "请输入正确编号!"
		    sleep 2
            Home
    esac
}
# 解压zip
function unzipd()
{
    cecho "\033[31m  [请输入解压的文件名]: \033[0m"
    read -p ": " wenjian
    7z x "$home/tmp/$wenjian" -o"$home/tmp/" > /dev/null
        if [ $? -eq 0 ]; then
            cecho "\033[32m 解压成功，已解压到tmp文件夹\033[0m"
            sleep 2
            #Home
        else
            cecho "\033[31m 解压失败\033[0m"
            sleep 2
            #Home
        fi
    Home
}
# 解压Br
function unbr()
{
    if ls -d $home/tmp/*.new.dat.br >/dev/null 2>&1;then
        cd $home/tmp
        for brs in $(ls *.new.dat.br)
        do 
        if [ -f "$brs" ] ; then
            unbr=$(echo "$brs" | rev |cut -d'.' -f1 --complement | rev | sed 's/.new.dat.br//g' | sed 's/.new.dat//g')
            cecho "\033[2;32m 正在解压$unbr 的Br文件\033[0m"
            $brotli -d $unbr.new.dat.br
            rm -rf $unbr.new.dat.br
        fi
        done
    fi
    Home
}
# 解压Dat
function undat()
{
    if ls -d $home/tmp/*.new.dat >/dev/null 2>&1;then
        cd $home/tmp
        for dats in $(ls *.new.dat)
        do 
        if [ -f "$dats" ] ; then
            datss=$(echo $dats)
            undat=$(echo "$datss" | rev |cut -d'.' -f1 --complement | rev | sed 's/.new.dat//g' | sed 's/.new//g')
            cecho "\033[2;32m 正在解压$undat 的Dat文件\033[0m"
            python3 $bin/sdat2img.py $home/tmp/$undat.transfer.list $home/tmp/$undat.new.dat $home/image/$undat.img > /dev/null
            rm -rf $undat.new.dat $undat.transfer.list $undat.patch.dat
        fi
        done
    fi
    Home
}
# 解压Img
function unimg()
{
    function unext()
    {
        cd $home/image
        for ext in $(ls *.img)
        do 
        if [ -f "$ext" ] ; then
            unext4=$(echo "$ext" | rev |cut -d'.' -f1 --complement | rev | sed 's/.img//g')
            cecho "\033[2;32m 正在解压$unext4 的Ext4的Img文件\033[0m"
            sudo python3 $bin/imgextractor.py $home/image/$unext4.img $home/out > /dev/null
            sudo chmod -R 777 $home/out
        fi
        done
    }
    function unerofs()
    {
        cd $home/image
        for erofs in $(ls *.img)
        do 
        if [ -f "$erofs" ] ; then
            unerofss=$(echo "$erofs" | rev |cut -d'.' -f1 --complement | rev | sed 's/.img//g')
            cecho "\033[2;32m 正在解压$unerofss 的Erofs的Img文件\033[0m"
            sudo $erofsUnpackKt $home/image/$unerofss.img $home/out > /dev/null
            sudo chmod -R 777 $home/out
            if [ -f $home/out/erofs.txt ]; then
                echo "$unerofss" >> $home/out/erofs.txt
                cecho "\033[2;32m $unerofss erofs格式已保存\033[0m"
            else
                touch $home/out/erofs.txt
                echo "$unerofss" >> $home/out/erofs.txt
                cecho "\033[2;32m $unerofss erofs格式已保存\033[0m"
            fi
        fi
        done
    }

    if ls -d $home/image/*.img >/dev/null 2>&1;then
        gettype2=`$gettype1 -i $home/image/*.img`
        if [ "$gettype2" == "ext" ];then
            cecho "\033[2;32m 检测到为Ext4格式\033[0m"
            unext
        elif [ "$gettype2" == "erofs" ];then
            cecho "\033[2;32m 检测到为Erofs格式\033[0m"
            unerofs
        else
            cecho "\033[2;32m 未知格式！\033[0m"
        fi
    fi
    Home
}
# 解压Super
function unsuper() 
{
    if [ -f ./rom/tmp/super.img ]; then
        cecho "\033[32m Super.img文件存在\033[0m"
        if (file ./rom/tmp/super.img | grep -qo "sparse") ;then
            cecho "\033[32m 检测到Super.img为simg\033[0m"
	        cecho "\033[32m 转换为rimg中...\033[0m"
	        $simg2img ./rom/tmp/super.img ./rom/tmp/superr.img
            cecho "\033[32m 转换完成\033[0m"
        else
            cecho "\033[32m 当前super.img是raw文件\033[0m"
            mv ./rom/tmp/super.img ./rom/tmp/superr.img
        fi
        super_size=$(du -sb "./rom/tmp/superr.img" | awk '{print $1}' | bc -q)
        cecho "\033[32m Super.img大小为$super_size bytes  解压super.img中...\033[0m"
        super=./rom/super
        mkdir -p $super
        $lpunpack ./rom/tmp/superr.img ./rom/super
        if [ $? -eq 0 ]; then
            mv -i ./rom/super/* ./rom/image
            rm -rf ./rom/super
            rm -rf ./rom/super.img
            rm -rf ./rom/superr.img
            cecho "\033[32m 解压成功，已解压到image文件夹\033[0m"
            sleep 2
            #Home
        else
            cecho "\033[31m 解压失败\033[0m"
            sleep 2
            #Home
        fi
    fi
 Home 
}
# 解压Payload
function jieyabin() 
{
    if [ -f $home/tmp/payload.bin ]; then
        cecho "\033[32m payload.bin文件存在\033[0m"
        cecho "\033[32m 正在尝试解压payload.bin\033[0m"
        payload_size=$(du -sb "./rom/tmp/payload.bin" | awk '{print $1}' | bc -q)
        cecho "\033[32m Payload分区大小: $payload_size B  解压Payload.bin中...\033[0m"
        $payload_un ./rom/tmp/payload.bin ./rom/tmp/ > /dev/null
        if [ $? -eq 0 ]; then
            cecho "\033[32m 解压成功，已解压到image文件夹\033[0m"
        else
            cecho "\033[31m 解压失败\033[0m"
        fi
        mv ./payload/* $home/tmp/
        if [ -f $home/tmp/system.img ]; then
            mv $home/tmp/system.img $home/image/system.img
            cecho "\033[32m 已将system.img移动到image文件夹\033[0m"
        fi
        if [ -f $home/tmp/vendor.img ]; then
            mv $home/tmp/vendor.img $home/image/vendor.img
            cecho "\033[32m 已将vendor.img移动到image文件夹\033[0m"
        fi
        if [ -f $home/tmp/product.img ]; then
            mv $home/tmp/product.img $home/image/product.img
            cecho "\033[32m 已将product.img移动到image文件夹\033[0m"
        fi
        if [ -f $home/tmp/system_ext.img ]; then
            mv $home/tmp/system_ext.img $home/image/system_ext.img
            cecho "\033[32m 已将system_ext.img移动到image文件夹\033[0m"
        fi
        if [ -f $home/tmp/odm.img ]; then
            mv $home/tmp/odm.img $home/image/odm.img
            cecho "\033[32m 已将odm.img移动到image文件夹\033[0m"
        fi
    fi
    rm -rf ./payload
    rm -rf $home/tmp/payload.bin
    Home
}
# 打包Image
function makeimgg()
{
    if ls $home/out >/dev/null 2>&1;then
        cd $home/out
        for makeimg in $(ls | grep -vw -E 'config|image|erofs.txt|boot|vendor_boot')
        do 
            if [ -f $home/out/erofs.txt ];then
                cecho "\033[31m 存在Erofs保存文件，执行Erofs打包\033[0m"
                cecho "\033[32m 检测到$makeimg 为Erofs格式，执行Erofs打包\033[0m"
                cecho "\033[32m 开始打包$makeimg\033[0m"
                size=$(du -sb "$home/out/${makeimg}" | awk '{print $1}' | bc -q)
                cecho "\033[32m $makeimg 大小为$size B\033[0m"
                cecho "\033[32m 修复权限中...\033[0m"
                python3 $bin/fspatch.py $home/out/$makeimg $home/out/config/${makeimg}_fs_config > /dev/null
                cecho "\033[32m 修复完成，开始打包$makeimg ...\033[0m"
                sudo $mkfs --mount-point $makeimg --fs-config-file $home/out/config/${makeimg}_fs_config --file-contexts $home/out/config/${makeimg}_file_contexts $home/out/image/$makeimg.img $home/out/$makeimg > /dev/null
                if [ $? -eq 0 ]; then
                    cecho "\033[32m 打包$makeimg 成功\033[0m"
                else
                    cecho "\033[31m 打包$makeimg 失败\033[0m"
                fi
            else
                cecho "\033[31m 不存在Erofs保存文件，执行Ext4打包\033[0m"
                cecho "\033[32m 开始打包$makeimg\033[0m"
                size=$(du -sb "$home/out/${makeimg}" | awk '{print $1}' | bc -q)
                cecho "\033[32m $makeimg 大小为$size B\033[0m"
                cecho "\033[32m 正在计算打包大小...\033[0m"
                img_size0=`du -sb $home/out/${makeimg} | awk {'print $1'}`
                img_size00=`echo "$img_size0 * 1.1" |bc`  
                sizee=`echo "$img_size00 / 4096" |bc`
                cecho "\033[32m 打包大小为$sizee\033[0m"
                cecho "\033[32m 正在打包$makeimg...\033[0m"
                python3 $bin/fspatch.py $home/out/$makeimg $home/out/config/${makeimg}_fs_config > /dev/null
                $bin/Linux/mke2fs -O ^has_journal -L / -I 256 -M // -m 0 -t ext4 -b 4096 $home/out/$makeimg.img $sizee > /dev/null
                sudo $e2fsdroid -e -T 0 -S $home/out/config/${makeimg}_file_contexts -C $home/out/config/${makeimg}_fs_config  -a /$makeimg -f $home/out/$makeimg $home/out/$makeimg.img > /dev/null
                if [ $? -eq 0 ]; then
                    mv -i $home/out/$makeimg.img $home/out/image/$makeimg.img
                    cecho "\033[32m 打包$makeimg 成功\033[0m"
                else
                    cecho "\033[31m 打包$makeimg 失败\033[0m"
                fi
            fi
        done
    fi
    Home
}
# 打包Dat
function makedat()
{
    function makedatt()
    {
        sudo python3 $bin/img2sdat/img2sdat.py $home/out/image/$image.img -v 4
    }
    if ls -d $home/out/image/*.img >/dev/null 2>&1;then
        cd $home/out/image/
        for images in $(ls *.img)
        do 
        image=$(echo "$images" | rev |cut -d'.' -f1 --complement | rev | sed 's/.img//g')
        if (file $home/out/image/$image.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到$$image.img为simg 直接执行打包\033[0m"
            makedatt
        else
            cecho "\033[31m 当前$image.img是raw文件 正在转化成为Simg\033[0m"
            sudo $img2simg $home/out/image/$image.img $home/out/image/$image.simg
            rm -rf $home/out/image/$image.img
            mv -f $home/out/image/$image.simg $home/out/image/$image.img
            cecho "\033[31m 转化完成，正在执行打包\033[0m"
            makedatt    
        fi
        done
    fi
    Home
}
# 打包Br
function makebr()
{
    if ls -d $home/out/image/*.new.dat >/dev/null 2>&1;then
        cd $home/out/image
        for dat in $(ls *.new.dat)
        do 
        datt=$(echo "$dat" | rev |cut -d'.' -f1 --complement | rev | sed 's/.new.dat//g' | sed 's/.new//g')
        cecho "\033[32m 检测到$datt.new.dat,正在转为br\033[0m"
        $brotli -q 0 $home/out/image/${datt}.new.dat -o $home/out/${datt}.new.dat.br
        rm -rf $home/out/image/${datt}.new.dat
        cecho "\033[32m 转换完成\033[0m"
        done
    fi
    Home
}
# 打包super
function makesuper()
{
    mkdir -p $home/out/super
    cp -i $bin/makesuper.sh $LOCALDIR/makesuper.sh
    #cp -i $bin/rimg2simg.sh $LOCALDIR/rimg2simg.sh
    bash $LOCALDIR/makesuper.sh
    sleep 2
    Home
}
function makezip()
{
    cecho "\033[2;32m 正在查找生成的Img文件\033[0m"
    shengcheng=`find $home/out/image -name "*.img"`
    cecho "\033[2;32m 查找完成\033[0m"
    if [ -d $home/打包文件 ];then
        rm -rf $home/打包文件
        cp -r $bin/rompackage $home/打包文件
    else
        cp -r $bin/rompackage $home/打包文件
    fi
    cecho "\033[2;32m 正在移动生成的Img文件\033[0m"
    mv $shengcheng $home/打包文件/images/
    cecho "\033[2;32m 移动完成\033[0m"
    cecho "\033[2;32m 正在压缩为ZIP文件\033[0m"
    read -p "请输入生成的名称(不要带后缀)：" name
    7z a -tzip -r $name.zip $home/打包文件/* >/dev/null
    if [ $? -eq 0 ]; then
        cecho "\033[2;32m 压缩完成\033[0m"
        cecho "\033[2;32m 正在删除打包文件\033[0m"
        rm -rf $home/打包文件
        cecho "\033[2;32m 删除完成\033[0m"
    else
        cecho "\033[2;31m 压缩失败\033[0m"
    fi
    Home
}
# 打开主页
function gengxin()
{
    updatev=$(curl -s https://gitee.com/ChinaXB_admin/romtool-windowd/raw/master/bin/version)
    tikver=$(cat $bin/version)
    updatevv="https://github.com/IHABR/haihaihai"

    if [ $updatev -gt $tikver ]; then
        cecho "\e[1;31m 检测到更新：[$updatev]...\e[0m"
        cecho "\e[1;31m 请到$updatevv 处下载更新！\e[0m"
    else
        cecho "\e[1;32m 未检测到更新：[$tikver]...\e[0m"
        sleep 2
        Home
    fi
}
function huanjing()
{
    if [[ ! -f "$bin/configure" ]]; then
        echo -e "\033[2;32m 正在配置环境，请稍后！\033[0m"
        apt="python3 python3-pip curl default-jre bc android-sdk-libsparse-utils aria2 openjdk-8-jdk zip p7zip-full"
        PIP=https://pypi.tuna.tsinghua.edu.cn/simple/
        sudo apt install $apt -y
        pip install --upgrade pip -i $PIP
        pip install pycryptodome -i $PIP
        pip install mttkinter -i $PIP
        pip install docopt -i $PIP
        pip install requests -i $PIP
        pip install beautifulsoup4 -i $PIP
        pip install --ignore-installed pyyaml -i $PIP
        if [ -e ./rom ];then
        echo " 检测到ROM文件夹，跳过创建该文件夹"
        else
        echo " 未检测到ROM文件夹，正在创建ROM文件夹"
        sudo mkdir ./rom
        fi
        if [ -e ./rom/tmp ];then
        echo " 检测到输出文件夹，跳过创建该文件夹"
        else
        echo " 未检测到输出文件夹，正在创建输出文件夹"
        sudo mkdir ./rom/tmp
        fi
        if [ -e ./rom/out ];then
        echo " 检测到out文件夹，跳过创建该文件夹"
        else
        echo " 未检测到out文件夹，正在创建out文件夹"
        sudo mkdir ./rom/out
        fi
        if [ -e ./rom/out/config ];then
        echo " 检测到配置文件文件夹，跳过创建该文件夹"
        else
        echo " 未检测到配置文件文件夹，正在创建配置文件文件夹"
        sudo mkdir ./rom/out/config
        fi
        if [ -e ./rom/image ];then
        echo " 检测到Image文件夹，跳过创建该文件夹"
        else
        echo " 未检测到Image文件夹，正在创建Image文件夹"
        sudo mkdir ./rom/image
        fi
        if [ -e ./rom/out/image ];then
        echo " 检测到输出Image文件夹，跳过创建该文件夹"
        else
        echo " 未检测到输出Image文件夹，正在创建输出Image文件夹"
        sudo mkdir ./rom/out/image
        fi
        sudo chmod -R 777 $LOCALDIR
        echo -e "\033[2;33m环境配置完成\033[0m"
        touch $bin/configure
        gengxin
    else
        gengxin
    fi
}
huanjing