#!/bin/sh
LOCALDIR="$(cd $(dirname $0); pwd)"
bin=$LOCALDIR/bin
home=$LOCALDIR/rom
brotli=$bin/Linux/brotli
sdat2img=$bin/sdat2img.py
gettype1=$bin/Linux/gettype
simg2img=$bin/Linux/simg2img
lpunpack=$bin/Linux/lpunpack
payload_un=$bin/Linux/payload-dumper-go
erofsUnpackKt=$bin/Linux/erofsUnpackKt
mkfs=$bin/Linux/mkfs.erofs
mke2fs=$bin/Linux/mke2fs
e2fsdroid=$bin/Linux/e2fsdroid
img2simg=$bin/Linux/img2simg
SYSTEM_DIR=$home/out/system
ApkTool="java -jar $bin/apktool.jar"
SYSTEM_AVB=$home/out
AIK="$bin/AIK"
img2simg=$bin/Linux/img2simg

cecho(){ echo -e "\033[31m[$(date '+%H:%M:%S')]${1}\033[0m" ; } #颜色红

function Home()
{
    if [ -f $LOCALDIR/makesuper.sh ]; then
        rm -rf $LOCALDIR/makesuper.sh
    fi
    if [ -f $LOCALDIR/rimg2simg.sh ]; then
        rm -rf $LOCALDIR/rimg2simg.sh
    fi
    clear
    echo "-----------------------------------------------------------"
    echo -e "\033[1;31m|-              [欢迎使用MIUI通用处理工具]               -|\033[0m"
    echo -e "\033[2;33m|-----------------------[解压目录]------------------------|\033[0m"
    echo -e "\033[2;32m|      [1.解压zip     ]            [2.解压Br      ]       |\033[0m"
    echo -e "\033[2;32m|      [3.解压Dat     ]            [4.解压img     ]       |\033[0m"
    echo -e "\033[2;32m|      [5.解压Super   ]            [6.解压Payload ]       |\033[0m"
    echo -e "\033[2;33m|-----------------------[打包目录]------------------------|\033[0m"
    echo -e "\033[2;32m|      [7.打包zip     ]            [8.打包Br      ]       |\033[0m"
    echo -e "\033[2;32m|      [9.打包Dat     ]            [10.打包img    ]       |\033[0m"
    echo -e "\033[2;32m|      [11.打包Super  ]            [12.打包Payload]       |\033[0m"
    echo -e "\033[2;33m|---------------------------------------------------------|\033[0m"
    echo -e "\033[1;32m|                  [111.MIUI通用修改菜单]                 |\033[0m"
    echo -e "\033[1;32m|                  [    222.处理权限    ]                 |\033[0m"
    echo -e "\033[1;32m|                  [  333.删除全部文件  ]                 |\033[0m"
    echo -e "\033[2;33m|---------------------------------------------------------|\033[0m"
    echo -e "\033[1;31m|                         [0.退出]                        |\033[0m"
    echo "-----------------------------------------------------------"
    echo -e "\033[1;35m                      [请输入您的选择]\033[0m"
    read -p "--[请输入数字]: " xuanze
    case $xuanze in
        1)
            unzipd
        ;;
		2)
		    unbr
        ;;
		3)
		    undat
        ;;
		4)
            unimg
		;;
		5)
            unsuper
		;;		
		6)
            jieyabin
		;;		
		7)
            cecho "\033[1;31m 暂未开放\033[0m"
            sleep 2
            Home
        ;;
        8)
            makebr
        ;;
        9)
            makedat
        ;;
        10)
            makeimg
        ;;
        11)
            makesuper
        ;;
        12)
            cecho "\033[1;31m 暂未开放\033[0m"
            sleep 2
            Home
        ;;
        111)
            miuicaidan
        ;;
        222)
            cecho "\033[1;32m 正在处理权限...\033[0m"
            sleep 1
            sudo chmod -R 777 $home
            cecho "\033[1;32m 处理完成\033[0m"
            sleep 1
            Home
        ;;
        333)
            cecho "\033[1;32m 清除中...\033[0m"
            cp $bin/rm.sh $LOCALDIR/rm.sh
            bash ./rm.sh
            cecho "\033[1;32m 清除完成\033[0m"
            rm -rf ./rm.sh
            sleep 2
            Home
        ;;
        0)
            clear
            exit
		;;
        *)
            echo "请输入正确编号!"
		    sleep 2
            Home
    esac
}
# 解压zip
function unzipd()
{
    cecho "\033[31m  [请输入解压的文件名]: \033[0m"
    read -p "  ：" wenjian
    7z x "$home/tmp/$wenjian" -o"$home/tmp/" > /dev/null
        if [ $? -eq 0 ]; then
            cecho "\033[31m 解压成功，已解压到tmp文件夹\033[0m"
            sleep 2
            #Home
        else
            cecho "\033[31m 解压失败\033[0m"
            sleep 2
            #Home
        fi
    Home
}
# 解压br
function unbr()
{
    cecho "\033[31m 正在检测Br并解压\033[0m"
    if [ -f ./rom/tmp/system.new.dat.br ]; then
        cecho "\033[31m system.new.dat.br文件存在\033[0m"
        $brotli -d ./rom/tmp/system.new.dat.br
            if [ -f ./rom/tmp/system.new.dat ];then
                echo "system.new.dat.br解压解压完成"
                sleep 1
                rm -rf ./rom/tmp/system.new.dat.br
            fi
    fi
    if [ -f ./rom/tmp/vendor.new.dat.br ]; then
        cecho "\033[31m vendor.new.dat.br文件存在\033[0m"
        $brotli -d ./rom/tmp/vendor.new.dat.br
            if [ -f ./rom/tmp/vendor.new.dat ];then
                echo "vendor.new.dat.br解压解压完成"
                sleep 1
                rm -rf ./rom/tmp/vendor.new.dat.br
            fi
    fi
    if [ -f ./rom/tmp/product.new.dat.br ]; then
        cecho "\033[31m product.new.dat.br文件存在\033[0m"
        $brotli -d ./rom/tmp/product.new.dat.br
        if [ -f ./rom/tmp/product.new.dat ];then
            echo "product.new.dat.br解压解压完成"
            sleep 1
            rm -rf ./rom/tmp/product.new.dat.br
        fi
    fi
    if [ -f ./rom/tmp/system_ext.new.dat.br ]; then
        cecho "\033[31m system_ext.new.dat.br文件存在\033[0m"
        $brotli -d ./rom/tmp/system_ext.new.dat.br
        if [ -f ./rom/system_ext.new.dat ];then
            echo "system_ext.new.dat.br解压解压完成"
            sleep 1
            rm -rf ./rom/tmp/system_ext.new.dat.br
        fi
    fi
    if [ -f ./rom/tmp/odm.new.dat.br ]; then
        cecho "\033[31m odm.new.dat.br文件存在\033[0m"
        $brotli -d ./rom/tmp/odm.new.dat.br
        if [ -f ./rom/tmp/odm.new.dat ];then
            echo "odm.new.dat.br解压解压完成"
            sleep 1
            rm -rf ./rom/tmp/odm.new.dat.br
        fi
    fi
 Home
}
# 解压Dat
function undat()
{
    cecho "\033[31m 正在检测Dat并解压\033[0m"
    if [ -f $home/tmp/system.new.dat ]; then
        cecho "\033[31m system.new.dat文件存在\033[0m"
        sudo python3 $sdat2img $home/tmp/system.transfer.list $home/tmp/system.new.dat $home/image/system.img > /dev/null
    fi
    if [ -f $home/tmp/vendor.new.dat ]; then
        cecho "\033[31m vendor.new.dat文件存在\033[0m"
        sudo python3 $sdat2img $home/tmp/vendor.transfer.list $home/tmp/vendor.new.dat $home/image/vendor.img > /dev/null
    fi
    if [ -f $home/tmp/product.new.dat ]; then
        cecho "\033[31m product.new.dat文件存在\033[0m"
        sudo python3 $sdat2img $home/tmp/product.transfer.list $home/tmp/product.new.dat $home/image/product.img > /dev/null
    fi
    if [ -f $home/tmp/system_ext.new.dat ]; then
        cecho "\033[31m system_ext.new.dat文件存在\033[0m"
        sudo python3 $sdat2img $home/tmp/system_ext.transfer.list $home/tmp/system_ext.new.dat $home/image/system_ext.img > /dev/null
    fi
    if [ -f $home/tmp/odm.new.dat ]; then
        cecho "\033[31m odm.new.dat文件存在\033[0m"
        sudo python3 $sdat2img $home/tmp/odm.transfer.list $home/tmp/odm.new.dat $home/image/odm.img > /dev/null
        
    fi
    if [ -f $home/image/system.img ];then
        echo "system.new.dat解压解压完成"
        sleep 1
        rm -rf $home/tmp/system.new.dat
    fi
    if [ -f $home/image/vendor.img ];then
        echo "vendor.new.dat解压解压完成"
        sleep 1
        rm -rf $home/tmp/vendor.new.dat
    fi
    if [ -f $home/image/product.img ];then
        echo "product.new.dat解压解压完成"
        sleep 1
        rm -rf $home/tmp/product.new.dat
    fi
    if [ -f $home/image/system_ext.img ];then
        echo "system_ext.new.dat解压解压完成"
        sleep 1
        rm -rf $home/tmp/system_ext.new.dat
    fi
    if [ -f $home/image/odm.img ];then
        echo "odm.new.dat解压解压完成"
        sleep 1
        rm -rf $home/tmp/odm.new.dat
    fi
 Home
}
# 解压Img
function unimg()
{
    if [ -f $home/image/system_a.img ]; then
        mv -i $home/image/system_a.img $home/image/system.img
        rm -rf $home/image/system_b.img
    fi
    if [ -f $home/image/vendor_a.img ]; then
        mv -i $home/image/vendor_a.img $home/image/vendor.img
        rm -rf $home/image/vendor_b.img
    fi
    if [ -f $home/image/product_a.img ]; then
        mv -i $home/image/product_a.img $home/image/product.img
        rm -rf $home/image/product_b.img
    fi
    if [ -f $home/image/system_ext_a.img ]; then
        mv -i $home/image/system_ext_a.img $home/image/system_ext.img
        rm -rf $home/image/system_ext_b.img
    fi
    if [ -f $home/image/odm_a.img ]; then
        mv -i $home/image/odm_a.img $home/image/odm.img
        rm -rf $home/image/odm_b.img
    fi
    if [ -f $home/image/system.img ]; then
        if (file ./rom/image/system.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到system.img为simg\033[0m"
	        cecho "\033[31m 转换为rimg中...\033[0m"
	        $simg2img $home/image/system.img $home/image/systemr.img
            mv -i $home/image/systemr.img $home/image/system.img
            rm -rf $home/image/systemr.img
	        echo "转换完成"
        else
            cecho "\033[31m 检测到system.img为rimg\033[0m"
        fi
    fi
    if [ -f $home/image/vendor.img ]; then
        if (file ./rom/image/vendor.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到vendor.img为simg\033[0m"
	        cecho "\033[31m 转换为rimg中...\033[0m"
	        $simg2img $home/image/vendor.img $home/image/vendorr.img
            mv -i $home/image/vendorr.img $home/image/vendor.img
            rm -rf $home/image/vendorr.img
	        echo "转换完成"
        else
            cecho "\033[31m 检测到vendor.img为rimg\033[0m"
        fi
    fi
    if [ -f $home/image/product.img ]; then
        if (file ./rom/image/product.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到product.img为simg\033[0m"
	        cecho "\033[31m 转换为rimg中...\033[0m"
	        $simg2img $home/image/product.img $home/image/productr.img
            mv -i $home/image/productr.img $home/image/product.img
            rm -rf $home/image/productr.img
	        echo "转换完成"
        else
            cecho "\033[31m 检测到product.img为rimg\033[0m"
        fi
    fi
    if [ -f $home/image/system_ext.img ]; then
        if (file ./rom/image/system_ext.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到system_ext.img为simg\033[0m"
	        cecho "\033[31m 转换为rimg中...\033[0m"
	        $simg2img $home/image/system_ext.img $home/image/system_extr.img
            mv -i $home/image/system_extr.img $home/image/system_ext.img
            rm -rf $home/image/system_extr.img
	        echo "转换完成"
        else
            cecho "\033[31m 检测到system_ext.img为rimg\033[0m"
        fi
    fi
    if [ -f $home/image/odm.img ]; then
        if (file ./rom/image/odm.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到odm.img为simg\033[0m"
	        cecho "\033[31m 转换为rimg中...\033[0m"
	        $simg2img $home/image/odm.img $home/image/odmr.img
            mv -i $home/image/odmr.img $home/image/odm.img
            rm -rf $home/image/odmr.img
	        echo "转换完成"
        else
            cecho "\033[31m 检测到odm.img为rimg\033[0m"
        fi
    fi
    if [ -f ./rom/image/system.img ]; then
        gettype2=`$gettype1 -i ./rom/image/system.img`
        if [ "$gettype2" = "ext" ]; then
            cecho "\e[1;32m system 检测为Ext4文件系统 \e[0m"
            cecho "\e[1;32m system 正在执行Ext4解包程序 \e[0m"
            sudo python3 $bin/imgextractor.py ./rom/image/system.img ./rom/out > /dev/null
            if [ $? -eq 0 ]; then
                cecho "\e[1;32m system Ext4解包成功 \e[0m"
                sudo chmod -R 777 ./rom/out/system
            else
                cecho "\e[1;31m system Ext4解包失败 \e[0m"
            fi
        else
            cecho "\e[1;31m system 检测为Erofs文件系统 \e[0m"
            cecho "\e[1;31m system 正在执行Erofs解包程序 \e[0m"
            sudo $erofsUnpackKt ./rom/image/system.img ./rom/out > /dev/null
        if [ $? -eq 0 ]; then
            cecho "\e[1;32m Erofs system解包成功 \e[0m"
            sudo chmod -R 777 ./rom/out/system
                if [ -f ./rom/out/erofs.txt ]; then
                    echo "system.img" >> ./rom/out/erofs.txt
                    echo "system.img erofs格式已保存"
                else
                    touch ./rom/out/erofs.txt
                    echo "system.img" >> ./rom/out/erofs.txt
                    echo "system.img erofs格式已保存"
                fi
        else
            cecho "\e[1;31m Erofs system解包失败 \e[0m"
        fi
        fi
    fi
    if [ -f ./rom/image/vendor.img ]; then
        gettype2=`$gettype1 -i ./rom/image/vendor.img`
        if [ "$gettype2" = "ext" ]; then
            cecho "\e[1;32m vendor 检测为Ext4文件系统 \e[0m"
            cecho "\e[1;32m vendor 正在执行Ext4解包程序 \e[0m"
            sudo python3 $bin/imgextractor.py ./rom/image/vendor.img ./rom/out > /dev/null
            if [ $? -eq 0 ]; then
                cecho "\e[1;32m vendor Ext4解包成功 \e[0m"
                sudo chmod -R 777 ./rom/out/vendor
            else
                cecho "\e[1;31m vendor Ext4解包失败 \e[0m"
            fi
        else
            cecho "\e[1;31m vendor 检测为Erofs文件系统 \e[0m"
            cecho "\e[1;31m vendor 正在执行Erofs解包程序 \e[0m"
            sudo $erofsUnpackKt ./rom/image/vendor.img ./rom/out > /dev/null
        if [ $? -eq 0 ]; then
            cecho "\e[1;32m Erofs vendor解包成功 \e[0m"
            sudo chmod -R 777 ./rom/out/vendor
                if [ -f ./rom/out/erofs.txt ]; then
                    echo "vendor.img" >> ./rom/out/erofs.txt
                    echo "vendor.img erofs格式已保存"
                else
                    touch ./rom/out/erofs.txt
                    echo "vendor.img" >> ./rom/out/erofs.txt
                    echo "vendor.img erofs格式已保存"
                fi
        else
            cecho "\e[1;31m Erofs vendor解包失败 \e[0m"
        fi
        fi
    fi
    if [ -f ./rom/image/product.img ]; then
        gettype2=`$gettype1 -i ./rom/image/product.img`
        if [ "$gettype2" = "ext" ]; then
            cecho "\e[1;32m product 检测为Ext4文件系统 \e[0m"
            cecho "\e[1;32m product 正在执行Ext4解包程序 \e[0m"
            sudo python3 $bin/imgextractor.py ./rom/image/product.img ./rom/out > /dev/null
            if [ $? -eq 0 ]; then
                cecho "\e[1;32m product Ext4解包成功 \e[0m"
                sudo chmod -R 777 ./rom/out/product
            else
                cecho "\e[1;31m product Ext4解包失败 \e[0m"
            fi
        else
            cecho "\e[1;31m product 检测为Erofs文件系统 \e[0m"
            cecho "\e[1;31m product 正在执行Erofs解包程序 \e[0m"
            sudo $erofsUnpackKt ./rom/image/product.img ./rom/out > /dev/null
        if [ $? -eq 0 ]; then
            cecho "\e[1;32m Erofs product解包成功 \e[0m"
            sudo chmod -R 777 ./rom/out/product
                if [ -f ./rom/out/erofs.txt ]; then
                    echo "product.img" >> ./rom/out/erofs.txt
                    echo "product.img erofs格式已保存"
                else
                    touch ./rom/out/erofs.txt
                    echo "product.img" >> ./rom/out/erofs.txt
                    echo "product.img erofs格式已保存"
                fi
        else
            cecho "\e[1;31m Erofs product解包失败 \e[0m"
        fi
        fi
    fi
    if [ -f ./rom/image/system_ext.img ]; then
        gettype2=`$gettype1 -i ./rom/image/system_ext.img`
        if [ "$gettype2" = "ext" ]; then
            cecho "\e[1;32m system_ext 检测为Ext4文件系统 \e[0m"
            cecho "\e[1;32m system_ext 正在执行Ext4解包程序 \e[0m"
            sudo python3 $bin/imgextractor.py ./rom/image/system_ext.img ./rom/out > /dev/null
            if [ $? -eq 0 ]; then
                cecho "\e[1;32m system_ext Ext4解包成功 \e[0m"
                sudo chmod -R 777 ./rom/out/system_ext
            else
                cecho "\e[1;31m system_ext Ext4解包失败 \e[0m"
            fi
        else
            cecho "\e[1;31m system_ext 检测为Erofs文件系统 \e[0m"
            cecho "\e[1;31m system_ext 正在执行Erofs解包程序 \e[0m"
            sudo $erofsUnpackKt ./rom/image/system_ext.img ./rom/out > /dev/null
        if [ $? -eq 0 ]; then
            cecho "\e[1;32m Erofs system_ext解包成功 \e[0m"
            sudo chmod -R 777 ./rom/out/system_ext
                if [ -f ./rom/out/erofs.txt ]; then
                    echo "system_ext.img" >> ./rom/out/erofs.txt
                    echo "system_ext.img erofs格式已保存"
                else
                    touch ./rom/out/erofs.txt
                    echo "system_ext.img" >> ./rom/out/erofs.txt
                    echo "system_ext.img erofs格式已保存"
                fi
        else
            cecho "\e[1;31m Erofs system_ext解包失败 \e[0m"
        fi
        fi
    fi
    if [ -f ./rom/image/odm.img ]; then
        gettype2=`$gettype1 -i ./rom/image/odm.img`
        if [ "$gettype2" = "ext" ]; then
            cecho "\e[1;32m odm 检测为Ext4文件系统 \e[0m"
            cecho "\e[1;32m odm 正在执行Ext4解包程序 \e[0m"
            sudo python3 $bin/imgextractor.py ./rom/image/odm.img ./rom/out > /dev/null
            if [ $? -eq 0 ]; then
                cecho "\e[1;32m odm Ext4解包成功 \e[0m"
                sudo chmod -R 777 ./rom/out/odm
            else
                cecho "\e[1;31m odm Ext4解包失败 \e[0m"
            fi
        else
            cecho "\e[1;31m odm 检测为Erofs文件系统 \e[0m"
            cecho "\e[1;31m odm 正在执行Erofs解包程序 \e[0m"
            sudo $erofsUnpackKt ./rom/image/odm.img ./rom/out > /dev/null
        if [ $? -eq 0 ]; then
            cecho "\e[1;32m Erofs odm解包成功 \e[0m"
            sudo chmod -R 777 ./rom/out/odm
                if [ -f ./rom/out/erofs.txt ]; then
                    echo "odm.img" >> ./rom/out/erofs.txt
                    echo "odm.img erofs格式已保存"
                else
                    touch ./rom/out/erofs.txt
                    echo "odm.img" >> ./rom/out/erofs.txt
                    echo "odm.img erofs格式已保存"
                fi
        else
            cecho "\e[1;31m Erofs odm解包失败 \e[0m"
        fi
        fi
    fi
    Home
}
# 解压Super
function unsuper() 
{
    if [ -f ./rom/tmp/super.img ]; then
        cecho "\033[31m Super.img文件存在\033[0m"
        if (file ./rom/tmp/super.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到Super.img为simg\033[0m"
	        cecho "\033[31m 转换为rimg中...\033[0m"
	        $simg2img ./rom/tmp/super.img ./rom/tmp/superr.img
	        echo "转换完成"
        else
            echo "当前super.img是raw文件"
            mv ./rom/tmp/super.img ./rom/tmp/superr.img
        fi
        super_size=$(du -sb "./rom/tmp/superr.img" | awk '{print $1}' | bc -q)
	    echo "super分区大小: $super_size bytes  解压super.img中..."
        super=./rom/super
        mkdir -p $super
        $lpunpack ./rom/tmp/superr.img ./rom/super
        if [ $? -eq 0 ]; then
            mv -i ./rom/super/* ./rom/image
            rm -rf ./rom/super
            rm -rf ./rom/super.img
            rm -rf ./rom/superr.img
            cecho "\033[31m 解压成功，已解压到image文件夹\033[0m"
            sleep 2
            #Home
        else
            cecho "\033[31m 解压失败\033[0m"
            sleep 2
            #Home
        fi
    fi
 Home 
}
# 解压payload
function jieyabin() 
{
    if [ -f $home/tmp/payload.bin ]; then
        cecho "\033[31m payload.bin文件存在\033[0m"
        cecho "\033[31m 正在尝试解压payload.bin\033[0m"
        payload_size=$(du -sb "./rom/tmp/payload.bin" | awk '{print $1}' | bc -q)
        echo "payload分区大小: $payload_size B  解压payload.bin中..."
        $payload_un ./rom/tmp/payload.bin ./rom/tmp/ > /dev/null
        if [ $? -eq 0 ]; then
            cecho "\033[31m 解压成功，已解压到image文件夹\033[0m"
        else
            cecho "\033[31m 解压失败\033[0m"
        fi
        mv ./payload/* $home/tmp/
        if [ -f $home/tmp/system.img ]; then
            mv $home/tmp/system.img $home/image/system.img
            cecho "\033[31m 已将system.img移动到image文件夹\033[0m"
        fi
        if [ -f $home/tmp/vendor.img ]; then
            mv $home/tmp/vendor.img $home/image/vendor.img
            cecho "\033[31m 已将vendor.img移动到image文件夹\033[0m"
        fi
        if [ -f $home/tmp/product.img ]; then
            mv $home/tmp/product.img $home/image/product.img
            cecho "\033[31m 已将product.img移动到image文件夹\033[0m"
        fi
        if [ -f $home/tmp/system_ext.img ]; then
            mv $home/tmp/system_ext.img $home/image/system_ext.img
            cecho "\033[31m 已将system_ext.img移动到image文件夹\033[0m"
        fi
        if [ -f $home/tmp/odm.img ]; then
            mv $home/tmp/odm.img $home/image/odm.img
            cecho "\033[31m 已将odm.img移动到image文件夹\033[0m"
        fi
    fi
    rm -rf ./payload
    rm -rf $home/tmp/payload.bin
 Home
}
# 打包Image
function makeimg()
{
    if [ -d ./rom/out/system ];then
        cecho "\033[31m 检测到System\033[0m"
        if [ -f ./rom/out/erofs.txt ];then
            cecho "\033[31m 存在Erofs保存文件，执行Erofs打包\033[0m"
            grep -q system.img ./rom/out/erofs.txt
            if [ $? -eq 0 ]; then
                cecho "\033[31m 检测到System为Erofs格式，执行Erofs打包\033[0m"
                cecho "\033[31m 开始打包system\033[0m"
                system_size=$(du -sb "./rom/out/system" | awk '{print $1}' | bc -q)
                cecho "\033[31m system大小为$system_size B\033[0m"
                cecho "\033[31m 修复权限中...\033[0m"
                python3 $bin/fspatch.py $home/out/system $home/out/config/system_fs_config > /dev/null
                cecho "\033[31m 修复完成，开始打包system...\033[0m"
                sudo $mkfs --mount-point system --fs-config-file $home/out/config/system_fs_config --file-contexts $home/out/config/system_file_contexts $home/out/image/system.img $home/out/system > /dev/null
                if [ $? -eq 0 ]; then
                    cecho "\033[31m 打包system成功\033[0m"
                else
                    cecho "\033[31m 打包system失败\033[0m"
                fi
            fi
        else
            cecho "\033[31m 不存在Erofs保存文件，执行Ext4打包\033[0m"
            cecho "\033[31m 开始打包system\033[0m"
            system_size=$(du -sb "./rom/out/system" | awk '{print $1}' | bc -q)
            cecho "\033[31m system大小为$system_size B\033[0m"
            cecho "\033[31m 正在计算打包大小...\033[0m"
            system_size0=$(cat $home/out/config/system_size.txt)
            system_img_size0=`du -sb $home/out/system | awk {'print $1'}`
            system_img_size0=`echo "$system_img_size0 * 1.1" |bc`  
            system_img_size=`echo $system_img_size0 | sed 's/\..*//g'`
            system_size=`echo "$system_img_size0 / 4096" |bc`
            cecho "\033[31m 打包大小为$system_size\033[0m"
            cecho "\033[31m 正在打包System...\033[0m"
            python3 $bin/fspatch.py $home/out/system $home/out/config/system_fs_config > /dev/null
            $bin/Linux/mke2fs -O ^has_journal -L / -I 256 -M // -m 0 -t ext4 -b 4096 $home/out/system.img $system_size > /dev/null
            sudo $e2fsdroid -e -T 0 -S $home/out/config/system_file_contexts -C $home/out/config/system_fs_config  -a /system -f $home/out/system $home/out/system.img > /dev/null
            if [ $? -eq 0 ]; then
                cecho "\033[31m 打包system成功\033[0m"
            else
                cecho "\033[31m 打包system失败\033[0m"
            fi
        fi
    fi
    if [ -d ./rom/out/vendor ];then
        cecho "\033[31m 检测到vendor\033[0m"
        if [ -f ./rom/out/erofs.txt ];then
            cecho "\033[31m 存在Erofs保存文件，执行Erofs打包\033[0m"
            grep -q vendor.img ./rom/out/erofs.txt
            if [ $? -eq 0 ]; then
                cecho "\033[31m 检测到vendor为Erofs格式，执行Erofs打包\033[0m"
                cecho "\033[31m 开始打包vendor\033[0m"
                vendor_size=$(du -sb "./rom/out/vendor" | awk '{print $1}' | bc -q)
                cecho "\033[31m vendor大小为$vendor_size B\033[0m"
                cecho "\033[31m 修复权限中...\033[0m"
                3 $bin/fspatch.py $home/out/vendor $home/out/config/vendor_fs_config > /dev/null
                cecho "\033[31m 修复完成，开始打包vendor...\033[0m"
                sudo $mkfs --mount-point vendor --fs-config-file $home/out/config/vendor_fs_config --file-contexts $home/out/config/vendor_file_contexts $home/out/image/vendor.img $home/out/vendor > /dev/null
                if [ $? -eq 0 ]; then
                    cecho "\033[31m 打包vendor成功\033[0m"
                else
                    cecho "\033[31m 打包vendor失败\033[0m"
                fi
            fi
        else
            cecho "\033[31m 不存在Erofs保存文件，执行Ext4打包\033[0m"
            cecho "\033[31m 开始打包vendor\033[0m"
            vendor_size=$(du -sb "./rom/out/vendor" | awk '{print $1}' | bc -q)
            cecho "\033[31m vendor大小为$vendor_size B\033[0m"
            cecho "\033[31m 正在计算打包大小...\033[0m"
            vendor_size0=$(cat $home/out/config/vendor_size.txt)
            vendor_img_size0=`du -sb $home/out/vendor | awk {'print $1'}`
            vendor_img_size0=`echo "$vendor_img_size0 * 1.1" |bc`  
            vendor_img_size=`echo $vendor_img_size0 | sed 's/\..*//g'`
            vendor_size=`echo "$vendor_img_size0 / 4096" |bc`
            cecho "\033[31m 打包大小为$vendor_size\033[0m"
            cecho "\033[31m 正在打包vendor...\033[0m"
            python3 $bin/fspatch.py $home/out/vendor $home/out/config/vendor_fs_config > /dev/null
            $bin/Linux/mke2fs -O ^has_journal -L / -I 256 -M // -m 0 -t ext4 -b 4096 $home/out/vendor.img $vendor_size > /dev/null
            sudo $e2fsdroid -e -T 0 -S $home/out/config/vendor_file_contexts -C $home/out/config/vendor_fs_config  -a /vendor -f $home/out/vendor $home/out/vendor.img > /dev/null
            if [ $? -eq 0 ]; then
                cecho "\033[31m 打包vendor成功\033[0m"
            else
                cecho "\033[31m 打包vendor失败\033[0m"
            fi
        fi
    fi
    if [ -d ./rom/out/product ];then
        cecho "\033[31m 检测到product\033[0m"
        if [ -f ./rom/out/erofs.txt ];then
            cecho "\033[31m 存在Erofs保存文件，执行Erofs打包\033[0m"
            grep -q product.img ./rom/out/erofs.txt
            if [ $? -eq 0 ]; then
                cecho "\033[31m 检测到product为Erofs格式，执行Erofs打包\033[0m"
                cecho "\033[31m 开始打包product\033[0m"
                product_size=$(du -sb "./rom/out/product" | awk '{print $1}' | bc -q)
                cecho "\033[31m product大小为$product_size B\033[0m"
                cecho "\033[31m 修复权限中...\033[0m"
                python3 $bin/fspatch.py $home/out/product $home/out/config/product_fs_config > /dev/null
                cecho "\033[31m 修复完成，开始打包product...\033[0m"
                sudo $mkfs --mount-point product --fs-config-file $home/out/config/product_fs_config --file-contexts $home/out/config/product_file_contexts $home/out/image/product.img $home/out/product > /dev/null
                if [ $? -eq 0 ]; then
                    cecho "\033[31m 打包product成功\033[0m"
                else
                    cecho "\033[31m 打包product失败\033[0m"
                fi
            fi
        else
            cecho "\033[31m 不存在Erofs保存文件，执行Ext4打包\033[0m"
            cecho "\033[31m 开始打包product\033[0m"
            product_size=$(du -sb "./rom/out/product" | awk '{print $1}' | bc -q)
            cecho "\033[31m product大小为$product_size B\033[0m"
            cecho "\033[31m 正在计算打包大小...\033[0m"
            product_size0=$(cat $home/out/config/product_size.txt)
            product_img_size0=`du -sb $home/out/product | awk {'print $1'}`
            product_img_size0=`echo "$product_img_size0 * 1.1" |bc`  
            product_img_size=`echo $product_img_size0 | sed 's/\..*//g'`
            product_size=`echo "$product_img_size0 / 4096" |bc`
            cecho "\033[31m 打包大小为$product_size\033[0m"
            cecho "\033[31m 正在打包product...\033[0m"
            python3 $bin/fspatch.py $home/out/product $home/out/config/product_fs_config > /dev/null
            $bin/Linux/mke2fs -O ^has_journal -L / -I 256 -M // -m 0 -t ext4 -b 4096 $home/out/product.img $product_size > /dev/null
            sudo $e2fsdroid -e -T 0 -S $home/out/config/product_file_contexts -C $home/out/config/product_fs_config  -a /product -f $home/out/product $home/out/product.img > /dev/null
            if [ $? -eq 0 ]; then
                cecho "\033[31m 打包product成功\033[0m"
            else
                cecho "\033[31m 打包product失败\033[0m"
            fi
        fi
    fi
    if [ -d ./rom/out/system_ext ];then
        cecho "\033[31m 检测到system_ext\033[0m"
        if [ -f ./rom/out/erofs.txt ];then
            cecho "\033[31m 存在Erofs保存文件，执行Erofs打包\033[0m"
            grep -q system_ext.img ./rom/out/erofs.txt
            if [ $? -eq 0 ]; then
                cecho "\033[31m 检测到system_ext为Erofs格式，执行Erofs打包\033[0m"
                cecho "\033[31m 开始打包system_ext\033[0m"
                system_ext_size=$(du -sb "./rom/out/system_ext" | awk '{print $1}' | bc -q)
                cecho "\033[31m system_ext大小为$system_ext_size B\033[0m"
                cecho "\033[31m 修复权限中...\033[0m"
                python3 $bin/fspatch.py $home/out/system_ext $home/out/config/system_ext_fs_config > /dev/null
                cecho "\033[31m 修复完成，开始打包system_ext...\033[0m"
                sudo $mkfs --mount-point system_ext --fs-config-file $home/out/config/system_ext_fs_config --file-contexts $home/out/config/system_ext_file_contexts $home/out/image/system_ext.img $home/out/system_ext > /dev/null
                if [ $? -eq 0 ]; then
                    cecho "\033[31m 打包system_ext成功\033[0m"
                else
                    cecho "\033[31m 打包system_ext失败\033[0m"
                fi
            fi
        else
            cecho "\033[31m 不存在Erofs保存文件，执行Ext4打包\033[0m"
            cecho "\033[31m 开始打包system_ext\033[0m"
            system_ext_size=$(du -sb "./rom/out/system_ext" | awk '{print $1}' | bc -q)
            cecho "\033[31m system_ext大小为$system_ext_size B\033[0m"
            cecho "\033[31m 正在计算打包大小...\033[0m"
            system_ext_size0=$(cat $home/out/config/system_ext_size.txt)
            system_ext_img_size0=`du -sb $home/out/system_ext | awk {'print $1'}`
            system_ext_img_size0=`echo "$system_ext_img_size0 * 1.1" |bc`  
            system_ext_img_size=`echo $system_ext_img_size0 | sed 's/\..*//g'`
            system_ext_size=`echo "$system_ext_img_size0 / 4096" |bc`
            cecho "\033[31m 打包大小为$system_ext_size\033[0m"
            cecho "\033[31m 正在打包system_ext...\033[0m"
            python3 $bin/fspatch.py $home/out/system_ext $home/out/config/system_ext_fs_config > /dev/null
            $bin/Linux/mke2fs -O ^has_journal -L / -I 256 -M // -m 0 -t ext4 -b 4096 $home/out/system_ext.img $system_ext_size > /dev/null
            sudo $e2fsdroid -e -T 0 -S $home/out/config/system_ext_file_contexts -C $home/out/config/system_ext_fs_config  -a /system_ext -f $home/out/system_ext $home/out/system_ext.img > /dev/null
            if [ $? -eq 0 ]; then
                cecho "\033[31m 打包system_ext成功\033[0m"
            else
                cecho "\033[31m 打包system_ext失败\033[0m"
            fi
        fi
    fi
    if [ -d ./rom/out/odm ];then
        cecho "\033[31m 检测到odm\033[0m"
        if [ -f ./rom/out/erofs.txt ];then
            cecho "\033[31m 存在Erofs保存文件，执行Erofs打包\033[0m"
            grep -q odm.img ./rom/out/erofs.txt
            if [ $? -eq 0 ]; then
                cecho "\033[31m 检测到odm为Erofs格式，执行Erofs打包\033[0m"
                cecho "\033[31m 开始打包odm\033[0m"
                odm_size=$(du -sb "./rom/out/odm" | awk '{print $1}' | bc -q)
                cecho "\033[31m odm大小为$odm_size B\033[0m"
                cecho "\033[31m 修复权限中...\033[0m"
                python3 $bin/fspatch.py $home/out/odm $home/out/config/odm_fs_config > /dev/null
                cecho "\033[31m 修复完成，开始打包odm...\033[0m"
                sudo $mkfs --mount-point odm --fs-config-file $home/out/config/odm_fs_config --file-contexts $home/out/config/odm_file_contexts $home/out/image/odm.img $home/out/odm > /dev/null
                if [ $? -eq 0 ]; then
                    cecho "\033[31m 打包odm成功\033[0m"
                else
                    cecho "\033[31m 打包odm失败\033[0m"
                fi
            fi
        else
            cecho "\033[31m 不存在Erofs保存文件，执行Ext4打包\033[0m"
            cecho "\033[31m 开始打包odm\033[0m"
            odm_size=$(du -sb "./rom/out/odm" | awk '{print $1}' | bc -q)
            cecho "\033[31m odm大小为$odm_size B\033[0m"
            cecho "\033[31m 正在计算打包大小...\033[0m"
            odm_size0=$(cat $home/out/config/odm_size.txt)
            odm_img_size0=`du -sb $home/out/odm | awk {'print $1'}`
            odm_img_size0=`echo "$odm_img_size0 * 1.1" |bc`  
            odm_img_size=`echo $odm_img_size0 | sed 's/\..*//g'`
            odm_size=`echo "$odm_img_size0 / 4096" |bc`
            cecho "\033[31m 打包大小为128M\033[0m"
            cecho "\033[31m 正在打包odm...\033[0m"
            python3 $bin/fspatch.py $home/out/odm $home/out/config/odm_fs_config > /dev/null
            $bin/Linux/mke2fs -O ^has_journal -L / -I 256 -M // -m 0 -t ext4 -b 4096 $home/out/odm.img 32768 > /dev/null
            sudo $e2fsdroid -e -T 0 -S $home/out/config/odm_file_contexts -C $home/out/config/odm_fs_config  -a /odm -f $home/out/odm $home/out/odm.img > /dev/null
            if [ $? -eq 0 ]; then
                cecho "\033[31m 打包odm成功\033[0m"
            else
                cecho "\033[31m 打包odm失败\033[0m"
            fi
        fi
    fi
    if [ -f $home/out/system.img ]; then
        mv $home/out/system.img $home/out/image/system.img
        cecho "\033[31m 已将system.img移动到image文件夹\033[0m"
    fi
    if [ -f $home/out/vendor.img ]; then
        mv $home/out/vendor.img $home/out/image/vendor.img
        cecho "\033[31m 已将vendor.img移动到image文件夹\033[0m"
    fi
    if [ -f $home/out/product.img ]; then
        mv $home/out/product.img $home/out/image/product.img
        cecho "\033[31m 已将product.img移动到image文件夹\033[0m"
    fi
    if [ -f $home/out/system_ext.img ]; then
        mv $home/out/system_ext.img $home/out/image/system_ext.img
        cecho "\033[31m 已将system_ext.img移动到image文件夹\033[0m"
    fi
    if [ -f $home/out/odm.img ]; then
        mv $home/out/odm.img $home/out/image/odm.img
        cecho "\033[31m 已将odm.img移动到image文件夹\033[0m"
    fi
    Home
}
# 打包Dta
function makedat()
{
    if [ -f $home/out/image/system.img ]; then
        if (file $home/out/image/system.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到system.img为simg\033[0m"
        else
            echo "当前system.img是raw文件"
            sudo $img2simg $home/out/image/system.img $home/out/image/system.simg
            rm -rf $home/out/image/system.img
            mv -f $home/out/image/system.simg $home/out/image/system.img
        fi
    fi
    if [ -f $home/out/image/vendor.img ]; then
        if (file $home/out/image/vendor.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到vendor.img为simg\033[0m"
        else
            echo "当前vendor.img是raw文件"
            sudo $img2simg $home/out/image/vendor.img $home/out/image/vendor.simg
            rm -rf $home/out/image/vendor.img
            mv -f $home/out/image/vendor.simg $home/out/image/vendor.img
        fi
    fi
    if [ -f $home/out/image/product.img ]; then
        if (file $home/out/image/product.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到product.img为simg\033[0m"
        else
            echo "当前product.img是raw文件"
            sudo $img2simg $home/out/image/product.img $home/out/image/product.simg
            rm -rf $home/out/image/product.img
            mv -f $home/out/image/product.simg $home/out/image/product.img
        fi
    fi
    if [ -f $home/out/image/system_ext.img ]; then
        if (file $home/out/image/system_ext.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到system_ext.img为simg\033[0m"
        else
            echo "当前system_ext.img是raw文件"
            sudo $img2simg $home/out/image/system_ext.img $home/out/image/system_ext.simg
            rm -rf $home/out/image/system_ext.img
            mv -f $home/out/image/system_ext.simg $home/out/image/system_ext.img
        fi
    fi
    if [ -f $home/out/image/odm.img ]; then
        if (file $home/out/image/odm.img | grep -qo "sparse") ;then
            cecho "\033[31m 检测到odm.img为simg\033[0m"
        else
            echo "当前odm.img是raw文件"
            sudo $img2simg $home/out/image/odm.img $home/out/image/odm.simg
            rm -rf $home/out/image/odm.img
            mv -f $home/out/image/odm.simg $home/out/image/odm.img
        fi
    fi
    if [ -f $home/out/image/system.img ]; then
        cecho "\033[31m 发现system.img,正在打包为Dat\033[0m"
        sudo python3 $bin/img2sdat/img2sdat.py $home/out/image/system.img -v 4
        mv -i ./system.new.dat $home/out/system.new.dat
        mv -i ./system.patch.dat $home/out/system.patch.dat
        mv -i ./system.transfer.list $home/out/system.transfer.list
        if [ -f $home/out/system.new.dat ]; then
            cecho "\033[31m 打包system.dat成功\033[0m"
        else
            cecho "\033[31m 打包system.dat失败\033[0m"
        fi
    fi
    if [ -f $home/out/image/vendor.img ]; then
        cecho "\033[31m 发现vendor.img,正在打包为Dat\033[0m"
        sudo python3 $bin/img2sdat/img2sdat.py $home/out/image/vendor.img -v 4
        mv -i ./system.new.dat $home/out/vendor.new.dat
        mv -i ./system.patch.dat $home/out/vendor.patch.dat
        mv -i ./system.transfer.list $home/out/vendor.transfer.list
        if [ -f $home/out/vendor.new.dat ]; then
            cecho "\033[31m 打包vendor.dat成功\033[0m"
        else
            cecho "\033[31m 打包vendor.dat失败\033[0m"
        fi
    fi
    if [ -f $home/out/image/product.img ]; then
        cecho "\033[31m 发现product.img,正在打包为Dat\033[0m"
        sudo python3 $bin/img2sdat/img2sdat.py $home/out/image/product.img -v 4
        mv -i ./system.new.dat $home/out/product.new.dat
        mv -i ./system.patch.dat $home/out/product.patch.dat
        mv -i ./system.transfer.list $home/out/product.transfer.list
        if [ -f $home/out/product.new.dat ]; then
            cecho "\033[31m 打包product.dat成功\033[0m"
        else
            cecho "\033[31m 打包product.dat失败\033[0m"
        fi
    fi
    if [ -f $home/out/image/system_ext.img ]; then
        cecho "\033[31m 发现system_ext.img,正在打包为Dat\033[0m"
        sudo python3 $bin/img2sdat/img2sdat.py $home/out/image/system_ext.img -v 4
        mv -i ./system.new.dat $home/out/system_ext.new.dat
        mv -i ./system.patch.dat $home/out/system_ext.patch.dat
        mv -i ./system.transfer.list $home/out/system_ext.transfer.list
        if [ -f $home/out/system_ext.new.dat ]; then
            cecho "\033[31m 打包system_ext.dat成功\033[0m"
        else
            cecho "\033[31m 打包system_ext.dat失败\033[0m"
        fi
    fi
    if [ -f $home/out/image/odm.img ]; then
        cecho "\033[31m 发现odm.img,正在打包为Dat\033[0m"
        sudo python3 $bin/img2sdat/img2sdat.py $home/out/image/odm.img -v 4
        mv -i ./system.new.dat $home/out/odm.new.dat
        mv -i ./system.patch.dat $home/out/odm.patch.dat
        mv -i ./system.transfer.list $home/out/odm.transfer.list
        if [ -f $home/out/odm.new.dat ]; then
            cecho "\033[31m 打包odm.dat成功\033[0m"
        else
            cecho "\033[31m 打包odm.dat失败\033[0m"
        fi
    fi
    Home
}
# 打包Br
function makebr()
{
    if [ -f $home/out/system.new.dat ];then
        echo "检测到system.new.dat,正在转为br"
        $brotli -q 0 $home/out/system.new.dat -o $home/out/system.new.dat.br
        rm -rf $home/out/system.new.dat
        echo "转换完成"
    fi
    if [ -f $home/out/vendor.new.dat ];then
        echo "检测到vendor.new.dat,正在转为br"
        $brotli -q 0 $home/out/vendor.new.dat -o $home/out/vendor.new.dat.br
        rm -rf $home/out/vendor.new.dat
        echo "转换完成"
    fi
    if [ -f $home/out/product.new.dat ];then
        echo "检测到product.new.dat,正在转为br"
        $brotli -q 0 $home/out/product.new.dat -o $home/out/product.new.dat.br
        rm -rf $home/out/product.new.dat
        echo "转换完成"
    fi
    if [ -f $home/out/system_ext.new.dat ];then
        echo "检测到system_ext.new.dat,正在转为br"
        $brotli -q 0 $home/out/system_ext.new.dat -o $home/out/system_ext.new.dat.br
        rm -rf $home/out/system_ext.new.dat
        echo "转换完成"
    fi
    if [ -f $home/out/odm.new.dat ];then
        echo "检测到odm.new.dat,正在转为br"
        $brotli -q 0 $home/out/odm.new.dat -o $home/out/odm.new.dat.br
        rm -rf $home/out/odm.new.dat
        echo "转换完成"
    fi
    Home
}
# 打包super
function makesuper()
{
    mkdir -p $home/out/super
    cp -i $bin/makesuper.sh $LOCALDIR/makesuper.sh
    cp -i $bin/rimg2simg.sh $LOCALDIR/rimg2simg.sh
    bash $LOCALDIR/makesuper.sh
    sleep 2
    Home
}
# MIUI通用修改
function miuicaidan()
{
    clear
    echo "-----------------------------------------------------------"
    echo -e "\033[1;32m|-                  [MIUI通用处理菜单]                   -|\033[0m"
    echo -e "\033[2;33m|-------------------------[菜单]--------------------------|\033[0m"
    echo -e "\033[2;33m|     [1.去除卡米     ]           [2.去除avb       ]      |\033[0m"
    echo -e "\033[2;33m|     [3.去除data加密 ]           [4.精简          ]      |\033[0m"
    echo -e "\033[2;33m|     [5.ZipAlign优化 ]           [6.去除10秒      ]      |\033[0m"
    echo -e "\033[2;33m|     [7.解Boot       ]           [8.打包Boot      ]      |\033[0m"
    echo -e "\033[2;33m|     [9.解Vendor_Boot]           [10.打Vendor_Boot]      |\033[0m"
    echo -e "\033[2;33m|---------------------------------------------------------|\033[0m"
    echo -e "\033[1;31m|                      [0.返回主菜单]                     |\033[0m"
    echo "-----------------------------------------------------------"
    echo -e "\033[1;35m                      [请输入您的选择]\033[0m"
    read -p "--[请输入数字]: " shuru
    case $shuru in
        1)
            kami
        ;;
		2)
		    unavb
        ;;
		3)
		    unavb
        ;;
		4)
            rmapp
		;;
		5)
            zipalign
		;;		
		6)
            untens
		;;	
        7)
            unboot
		;;
        8)
            makeboot
		;;
        9)
            unvendorboot
		;;
        10)
            makevendorboot
		;;	
        0)
            clear
            Home
		;;
        *)
            echo "请输入正确编号!"
		    sleep 2
            miuicaidan
    esac
}
function kami()
{
    if [[ ! -d $SYSTEM_DIR ]]; then
        echo "不存在system"
        miuicaidan
    fi
    if [[ -f $bin/apktool.jar ]]; then
        #ApkTool="java -jar $bin/apktool.jar" 
        echo "ApkTool版本:" && $ApkTool -version
    else
        cecho "\e[36m 没有找到apktool\e[0m"
        echo " 请在$bin 目录下查看是否有apktool "
        sleep 5
        miuicaidan
    fi
    read -p "请问当前刷机包是否是MIUI13 [1]是，[2]不是: " is_miui13
    if [ $is_miui13 -eq 1 ];then
        cecho "\e[31m  MIUI13无需破解卡米 \e[0m"
        cecho "\e[31m  MIUI13无需破解卡米 \e[0m"
        cecho "\e[31m  MIUI13无需破解卡米 \e[0m"
        sleep 5
        miuicaidan
    elif [ $is_miui13 -eq 2 ];then
        if [[ -f $SYSTEM_DIR/system/framework/services.jar ]]; then
            if [[ $(grep "classes.dex" $SYSTEM_DIR/system/framework/services.jar) == "" ]]; then	
                $ApkTool d -q -r -f -o $home/system/services $SYSTEM_DIR/system/framework/services.jar
                if [ -d $home/system/services ]; then
                    cecho "\e[36m 正在去除卡米\e[0m"
                    Crack_File=$(find $home/system/services/ -type f -name '*.smali' 2>/dev/null | xargs grep -rl '.method private checkSystemSelfProtection(Z)V' | sed 's/^\.\///' | sort)
                    sed -i '/^.method private checkSystemSelfProtection(Z)V/,/^.end method/{//!d}' $Crack_File
                    sed -i -e '/^.method private checkSystemSelfProtection(Z)V/a\    .locals 1\n\n    return-void' $Crack_File
                    $ApkTool b -q -f -o $SYSTEM_DIR/system/framework/services.jar $home/system/services
                    sudo rm -rf $home/system/services 2>/dev/null
                    sudo rm -rf $home/system
                    cecho "\e[36m 去除卡米成功 \e[0m"	
                    sleep 3		
                    miuicaidan	
                fi
            else
            cecho "\e[36m>>> 没有找到相关卡米文件 <<<\e[0m"
            sleep 5
            miuicaidan
            fi
        fi			
    else
        cecho "\e[36m 眼角膜捐了？看不见提示？？ \e[0m"
        sleep 5
        miuicaidan
    fi
}
function zipalign()
{
    find $home/out/ -name "*.apk" > ./app.txt
    cat app.txt | while read line
    do
        cecho "\033[2;32m ZipAlign已优化$line\033[0m"
        $bin/zipalign/zipalign -c -v 4 $line > /dev/null
    done
    sudo rm -rf $LOCALDIR/app.txt
    cecho "\033[1;32m ZipAlibn优化完成\033[0m"
    sleep 2
    miuicaidan
}
function unavb()
{
    cecho "\e[31m 开始尝试去除AVB验证以及data加密 \e[0m"
	fstab=$(sudo find $home/out/ -name "fstab*")
	if [[ $fstab == "" ]];then
		cecho "\e[31m >找不到相关文件,也许没有加密呢\e[0m"
		sleep 5
		miuicaidan
	else
		cecho "\e[31m 正在去除,请等待...\e[0m"
		for file in $fstab; do
			cp $file $home/$lin_dir
			sed -i 's/,avb.*system//g' $file
			sed -i 's/,avb,/,/g' $file
			sed -i 's/,avb_keys.*key//g' $file
			sed -i 's/fileencryption=ice/encryptable=ice/g' $file
		done
	fi
	for file1 in $fstab; do
		avb_is=$(grep "avb" $file1)
		data_is=$(grep "fileencryption=ice" $file1)
		if [[ $avb_is == "" ]];then
			cecho "\e[31m system加密去除成功\e[0m"
		else
			cecho "\e[31m system加密可能去除失败\e[0m"
		fi

		if [[ $data_is == "" ]];then
			cecho "\e[31m data加密去除成功\e[0m"
		else
			cecho "\e[31m data加密可能去除失败\e[0m"
		fi
	done
    rm -rf $home/fstab*
    if [ -d $home/tmp/firmware-update ]; then
        if [ -f $home/tmp/firmware-update/vbmeta.img ]; then
            rm -rf $home/tmp/firmware-update/vbmeta.img
            cp -i $bin/Avb/vbmeta.img $home/tmp/firmware-update/vbmeta.img
        fi
        if [ -f $home/tmp/firmware-update/vbmeta_system.img ]; then
            rm -rf $home/tmp/firmware-update/vbmeta_system.img
            cp -i $bin/Avb/vbmeta_system.img $home/tmp/firmware-update/vbmeta_system.img
        fi
        if [ -f $home/tmp/firmware-update/vbmeta_vendor.img ]; then
            rm -rf $home/tmp/firmware-update/vbmeta_vendor.img
            cp -i $bin/Avb/vbmeta_vendor.img $home/tmp/firmware-update/vbmeta_vendor.img
        fi
    fi
    if [ -f $home/tmp/vbmeta.img ]; then
        rm -rf $home/tmp/vbmeta.img
        cp -i $bin/Avb/vbmeta.img $home/tmp/vbmeta.img
    fi
    if [ -f $home/tmp/vbmeta_system.img ]; then
        rm -rf $home/tmp/vbmeta_system.img
        cp -i $bin/Avb/vbmeta_system.img $home/tmp/vbmeta_system.img
    fi
    if [ -f $home/tmp/vbmeta_vendor.img ]; then
        rm -rf $home/tmp/vbmeta_vendor.img
        cp -i $bin/Avb/vbmeta_vendor.img $home/tmp/vbmeta_vendor.img
    fi
    sleep 5
    miuicaidan
}
# 精简APP
function rmapp()
{
    cecho "\033[2;32m 正在搜索文件...\033[0m"
    cp -i $bin/rmapp.sh $LOCALDIR/rmapp.sh
    bash $LOCALDIR/rmapp.sh
    cecho "\033[2;32m 搜索完成，开始精简\033[0m"

    cat rmapp.txt | while read line
    do
        cecho "\033[2;32m 已精简$line\033[0m"
        rm -rf $line
        if [ -d $home/out/vendor/data-app ]; then
            rm -rf $home/out/vendor/data-app
            echo "$home/out/vendor/data-app" >> rmapp.txt
        fi
        if [ -d $home/out/product/data-app ]; then
            rm -rf $home/out/product/data-app
            echo "$home/out/product/data-app" >> rmapp.txt
        fi
    done
    rm -rf $LOCALDIR/rmapp.sh
    cecho "\033[2;32m 已精简$line\033[0m"
    cecho "\033[2;32m 精简完成\033[0m"
	sleep 5
	miuicaidan
}
# 去除10S
function untens()
{
    if [[ ! -d $SYSTEM_DIR ]]; then
		echo "不存在system"
		miuicaidan
	fi
	if [[ -f $bin/apktool.jar ]]; then
		ApkTool="java -jar $bin/apktool.jar" 
		echo "ApkTool版本:" && $ApkTool -version
		
	else
		cecho "\e[36m 没有找到apktool\e[0m"
		echo " 请在$bin 目录下查看是否有apktool "
		sleep 5
		miuicaidan
	fi
	if [ -d $home/SecurityCenter ]; then
		sudo rm -rf $home/SecurityCenter
	fi
	cecho "\033[1;31m 是否为 MIUI13 [1]是  [2]否\033[0m"
	read -p ":" shifou
	if [ $shifou -eq 1 ];then
		if [[ -f $SYSTEM_DIR/system/priv-app/MIUISecurityCenter/MIUISecurityCenter.apk ]]; then
			cecho "\e[36m 开始尝试去除10S\e[0m"
			cp $SYSTEM_DIR/system/priv-app/MIUISecurityCenter/MIUISecurityCenter.apk $home/$lin_dir/MIUISecurityCenter.apk.bak
			$ApkTool d -q -r -f -o $home/MIUISecurityCenter $SYSTEM_DIR/system/priv-app/MIUISecurityCenter/MIUISecurityCenter.apk		
			if [ -d $home/MIUISecurityCenter ]; then
				cecho "\e[36m 正在去除10S\e[0m"
				sed -i 's/const\/4 v0, 0x5/const\/4 v0, 0x0/g' $home/MIUISecurityCenter/smali_classes2/com/miui/permcenter/privacymanager/g.smali
				sed -i 's/const\/16 v0, 0xa/const\/16 v0, 0x0/g' $home/MIUISecurityCenter/smali_classes2/com/miui/permcenter/privacymanager/i.smali
				#cecho "\033[1;32m 尝试MIUI安全中心锁定100分\033[0m"
				#n=$(grep -n "return v1" $home/MIUISecurityCenter/smali_classes2/com/miui/securityscan/scanner/ScoreManager.smali | head -n 1)
				#m=${n%%:*}
				#sed -i "${m}iconst/16 v1, 0x64" $home/MIUISecurityCenter/smali_classes2/com/miui/securityscan/scanner/ScoreManager.smali
				$ApkTool b -q -f -o $SYSTEM_DIR/system/priv-app/MIUISecurityCenter/MIUISecurityCenter.apk $home/MIUISecurityCenter
				sudo rm -rf $home/MIUISecurityCenter
				cecho "\e[36m 去除10S成功\e[0m"
				sleep 3
				miuicaidan
			fi
			cecho "\e[36m 去除10S失败\e[0m"	
			sleep 3
			miuicaidan
			sudo rm -rf $home/MIUISecurityCenter.apk.bak
		fi
	elif [ $shifou -eq 2 ];then
		if [[ -f $SYSTEM_DIR/system/priv-app/SecurityCenter/SecurityCenter.apk ]]; then
			cecho "\e[36m 开始尝试去除10S\e[0m"
			cp $SYSTEM_DIR/system/priv-app/SecurityCenter/SecurityCenter.apk $home/$lin_dir/SecurityCenter.apk.bak
			$ApkTool d -q -r -f -o $home/SecurityCenter $SYSTEM_DIR/system/priv-app/SecurityCenter/SecurityCenter.apk		
			if [ -d $home/SecurityCenter ]; then
				cecho "\e[36m 正在去除10S\e[0m"
				sed -i 's/const\/4 v0, 0x5/const\/4 v0, 0x0/g' $home/SecurityCenter/smali_classes2/com/miui/permcenter/privacymanager/g.smali
				sed -i 's/const\/16 v0, 0xa/const\/16 v0, 0x0/g' $home/SecurityCenter/smali_classes2/com/miui/permcenter/privacymanager/i.smali
				cecho "\033[1;32m 尝试MIUI安全中心锁定100分\033[0m"
				n=$(grep -n "return v1" $home/SecurityCenter/smali_classes2/com/miui/securityscan/scanner/ScoreManager.smali | head -n 1)
				m=${n%%:*}
				sed -i "${m}iconst/16 v1, 0x64" $home/SecurityCenter/smali_classes2/com/miui/securityscan/scanner/ScoreManager.smali
				$ApkTool b -q -f -o $SYSTEM_DIR/system/priv-app/SecurityCenter/SecurityCenter.apk $home/SecurityCenter
				sudo rm -rf $home/SecurityCenter
				cecho "\e[36m 去除10S成功\e[0m"
				sleep 3
				miuicaidan
			fi
			cecho "\e[36m 去除10S失败\e[0m"	
			sleep 3
			miuicaidan
			sudo rm -rf $home/SecurityCenter.apk.bak
            sudo rm -rf $home/MIUISecurityCenter.apk.bak
		fi
	else
		cecho "\e[31m 请重新输入！ \e[0m"
	fi
	sleep 3
	miuicaidan
}
function unboot()
{
    cecho "\033[1;32m 正在解压boot...\033[0m"
	sudo $AIK/unpackimg.sh $home/tmp/boot.img > /dev/null
	mkdir -p $home/out/boot
	mv -i $AIK/ramdisk $home/out/boot/ramdisk
	mv -i $AIK/split_img $home/out/boot/split_img
	sleep 1
	if [ -d $home/out/boot/ramdisk ]; then
		if [ -d $home/out/boot/split_img ]; then
			cecho "\033[1;32m 解压boot成功！\033[0m"
		else
			cecho "\033[1;31m 解压boot失败！\033[0m"
		fi
	else
		cecho "\033[1;31m 解压boot失败！\033[0m"
	fi
	sleep 1
	miuicaidan
}
function unvendorboot()
{
    cecho "\033[1;32m 正在解压vendor_boot...\033[0m"
	sudo $AIK/unpackimg.sh $home/tmp/vendor_boot.img > /dev/null
	mkdir -p $home/out/vendor_boot
	mv -i $AIK/ramdisk $home/out/vendor_boot/ramdisk
	mv -i $AIK/split_img $home/out/vendor_boot/split_img
	sleep 1
	if [ -d $home/out/vendor_boot/ramdisk ]; then
		if [ -d $home/out/vendor_boot/split_img ]; then
			cecho "\033[1;32m 解压vendor_boot成功！\033[0m"
		else
			cecho "\033[1;31m 解压vendor_boot失败！\033[0m"
		fi
	else
		cecho "\033[1;31m 解压vendor_boot失败！\033[0m"
	fi
    sleep 1
	miuicaidan
}
function makeboot()
{
    cecho "\033[1;32m 正在生成boot中...\033[0m"
	cp -afr $home/out/boot/* $AIK
	$AIK/repackimg.sh --forceelf > /dev/null
	mv -i $AIK/image-new.img $home/out/image/boot.img
	rm -rf $AIK/split_img
	rm -rf $AIK/ramdisk
	if [ -e $AIK/ramdisk-new.cpio.gz ]; then
	rm -rf $AIK/ramdisk-new.cpio.gz
	fi
	if [ -e $AIK/ramdisk-new.cpio.lz4 ]; then
	rm -rf $AIK/ramdisk-new.cpio.lz4
	fi
	if [ -e $home/out/image/boot.img ]; then
	cecho "\033[1;32m 生成boot成功！\033[0m"
	else
	cecho "\033[1;31m 生成boot失败！\033[0m"
	fi
    sleep 1
	miuicaidan
}
function makevendorboot()
{
    cecho "\033[1;32m 正在生成vendor_boot中...\033[0m"
	cp -afr $home/out/vendor_boot/* $AIK
	$AIK/repackimg.sh --forceelf > /dev/null
	mv -i $AIK/image-new.img $home/out/image/vendor_boot.img
	rm -rf $AIK/split_img
	rm -rf $AIK/ramdisk
	if [ -e $AIK/ramdisk-new.cpio.gz ]; then
	rm -rf $AIK/ramdisk-new.cpio.gz
	fi
	if [ -e $AIK/ramdisk-new.cpio.lz4 ]; then
	rm -rf $AIK/ramdisk-new.cpio.lz4
	fi
	if [ -e $home/out/image/vendor_boot.img ]; then
	cecho "\033[1;32m 生成vendor_boot成功！\033[0m"
	else
	cecho "\033[1;31m 生成vendor_boot失败！\033[0m"
	fi
    sleep 1
	miuicaidan
}
# 打开主页
function gengxin()
{
    updatev=$(curl -s https://gitee.com/ChinaXB_admin/romtool-windowd/raw/master/bin/version)
    tikver=$(cat $bin/version)
    updatevv="https://github.com/IHABR/haihaihai"

    if [ $updatev -gt $tikver ]; then
        cecho "\e[1;31m 检测到更新：[$updatev]...\e[0m"
        cecho "\e[1;31m 请到$updatevv 处下载更新！\e[0m"
    else
        cecho "\e[1;32m 未检测到更新：[$tikver]...\e[0m"
        sleep 2
        Home
    fi
}
function huanjing()
{
    if [[ ! -f "$bin/configure" ]]; then
        echo -e "\033[2;32m 正在配置环境，请稍后！\033[0m"
        apt="python3 python3-pip curl default-jre bc android-sdk-libsparse-utils aria2 openjdk-8-jdk zip p7zip-full"
        PIP=https://pypi.tuna.tsinghua.edu.cn/simple/
        sudo apt install $apt -y
        pip install --upgrade pip -i $PIP
        pip install pycryptodome -i $PIP
        pip install mttkinter -i $PIP
        pip install docopt -i $PIP
        pip install requests -i $PIP
        pip install beautifulsoup4 -i $PIP
        pip install --ignore-installed pyyaml -i $PIP
        if [ -e ./rom ];then
        echo "检测到ROM文件夹，跳过创建该文件夹"
        else
        echo "未检测到ROM文件夹，正在创建ROM文件夹"
        sudo mkdir ./rom
        fi
        if [ -e ./rom/tmp ];then
        echo "检测到输出文件夹，跳过创建该文件夹"
        else
        echo "未检测到输出文件夹，正在创建输出文件夹"
        sudo mkdir ./rom/tmp
        fi
        if [ -e ./rom/out ];then
        echo "检测到out文件夹，跳过创建该文件夹"
        else
        echo "未检测到out文件夹，正在创建out文件夹"
        sudo mkdir ./rom/out
        fi
        if [ -e ./rom/out/config ];then
        echo "检测到配置文件文件夹，跳过创建该文件夹"
        else
        echo "未检测到配置文件文件夹，正在创建配置文件文件夹"
        sudo mkdir ./rom/out/config
        fi
        if [ -e ./rom/image ];then
        echo "检测到Image文件夹，跳过创建该文件夹"
        else
        echo "未检测到Image文件夹，正在创建Image文件夹"
        sudo mkdir ./rom/image
        fi
        if [ -e ./rom/out/image ];then
        echo "检测到输出Image文件夹，跳过创建该文件夹"
        else
        echo "未检测到输出Image文件夹，正在创建输出Image文件夹"
        sudo mkdir ./rom/out/image
        fi
        sudo chmod -R 777 $LOCALDIR
        echo -e "\033[2;33m环境配置完成\033[0m"
        touch $bin/configure
        gengxin
    else
        gengxin
    fi
}
huanjing